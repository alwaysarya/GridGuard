"""
GridGuard Configuration Management
Handles environment variables and application settings
"""

import os
from typing import List, Optional
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Settings:
    """Application settings loaded from environment variables"""
    
    # ========== API Settings ==========
    APP_NAME: str = "GridGuard AI"
    APP_VERSION: str = "1.0.0"
    APP_ENV: str = os.getenv("APP_ENV", "development")
    DEBUG: bool = APP_ENV == "development"
    API_PREFIX: str = "/api/v1"
    
    # ========== Security ==========
    SECRET_KEY: str = os.getenv("SECRET_KEY", "your-super-secret-key-change-this")
    API_KEY: str = os.getenv("API_KEY", "")
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    
    # ========== CORS Settings ==========
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8501",  # Streamlit frontend
        "http://localhost:8000",
    ]
    
    # ========== Database ==========
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL", 
        "postgresql://user:password@localhost:5432/gridguard"
    )
    DB_POOL_SIZE: int = int(os.getenv("DB_POOL_SIZE", "10"))
    DB_MAX_OVERFLOW: int = int(os.getenv("DB_MAX_OVERFLOW", "20"))
    
    # ========== Redis Cache ==========
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379")
    CACHE_TTL: int = 300  # 5 minutes
    
    # ========== ML Model Settings ==========
    MODEL_PATH: str = os.getenv(
        "MODEL_PATH", 
        "../ml_pipeline/models/production/model_v1.pkl"
    )
    SCALER_PATH: str = os.getenv(
        "SCALER_PATH",
        "../ml_pipeline/models/production/scaler.pkl"
    )
    FEATURE_NAMES_PATH: str = os.getenv(
        "FEATURE_NAMES_PATH",
        "../ml_pipeline/models/production/feature_names.json"
    )
    
    # ========== BESCOM Integration ==========
    BESCOM_API_URL: str = os.getenv("BESCOM_API_URL", "https://bescom-api.example.com")
    BESCOM_API_KEY: str = os.getenv("BESCOM_API_KEY", "")
    BESCOM_TIMEOUT: int = 30
    
    # ========== Alert Settings ==========
    ALERT_THRESHOLD: float = float(os.getenv("ALERT_THRESHOLD", "0.85"))
    ENABLE_SMS_ALERTS: bool = os.getenv("ENABLE_SMS_ALERTS", "true").lower() == "true"
    SMS_API_KEY: str = os.getenv("SMS_API_KEY", "")
    
    # ========== Monitoring ==========
    PROMETHEUS_PORT: int = int(os.getenv("PROMETHEUS_PORT", "9090"))
    ENABLE_METRICS: bool = True
    
    # ========== Rate Limiting ==========
    RATE_LIMIT_PER_MINUTE: int = int(os.getenv("RATE_LIMIT_PER_MINUTE", "100"))
    
    # ========== Logging ==========
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FORMAT: str = "json" if APP_ENV == "production" else "text"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# Create a single settings instance to import elsewhere
settings = Settings()

# Helper functions
def get_database_url() -> str:
    """Return database URL with proper formatting"""
    return settings.DATABASE_URL

def is_production() -> bool:
    """Check if running in production environment"""
    return settings.APP_ENV == "production"

def is_development() -> bool:
    """Check if running in development environment"""
    return settings.APP_ENV == "development"
