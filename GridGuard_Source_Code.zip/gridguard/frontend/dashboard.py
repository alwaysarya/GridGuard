import streamlit as st
import requests
import pandas as pd
from datetime import datetime

st.set_page_config(page_title="GridGuard - BESCOM", page_icon="⚡", layout="wide")

st.title("⚡ GridGuard - AI Smart Meter Intelligence")
st.subheader("BESCOM - Loss Detection & Theft Prevention")

API_URL = "http://localhost:8000"

# Sidebar for testing
st.sidebar.header("Test Anomaly Detection")
meter_id = st.sidebar.text_input("Meter ID", "MTR-001")
power = st.sidebar.number_input("Power (Watts)", value=5000.0)
voltage = st.sidebar.number_input("Voltage", value=230.0)

if st.sidebar.button("🔍 Test for Theft"):
    payload = {
        "meter_id": meter_id,
        "timestamp": datetime.now().isoformat(),
        "voltage": voltage,
        "current": power/230,
        "power": power,
        "energy_consumed": power/1000
    }
    try:
        response = requests.post(f"{API_URL}/api/v1/detection/detect-anomaly", json=payload)
        result = response.json()
        if result["is_anomaly"]:
            st.error(f"🚨 {result['message']}")
            st.warning(f"**Type:** {result['anomaly_type']}")
            st.warning(f"**Score:** {result['anomaly_score']}")
        else:
            st.success(f"✅ {result['message']}")
    except:
        st.error("❌ Backend not running!")

# Main dashboard
col1, col2, col3, col4 = st.columns(4)
col1.metric("Active Meters", "1,250", "▲ 12")
col2.metric("Active Alerts", "23", "▼ 5")
col3.metric("Detection Accuracy", "97.3%", "▲ 2.1%")
col4.metric("Theft Prevented", "156.5 MWh", "▲ 18%")

st.success("🎯 GridGuard is actively monitoring for energy theft!")
